#include "gnuplot-iostream/gnuplot-iostream.h"

#include <unistd.h>
#include<iostream>
#include<cmath>


inline void mysleep(unsigned millis) {
	::usleep(millis * 1000);
}

int init = 0;
int end = 100;

void planetGenerator(std::vector<std::pair<double, double> > *pts, int x, int y, double radio){
    double fact = 0.1;
	//(*pts).resize((radio+radio) / fact * 2);
    int init = 0;
    for(double i = x - radio ; i < x + radio; i+= fact) {
        std::cout << init << "** " << i << " " << sqrt(radio*radio - ((i - x)*(i - x)) + y) << std::endl;
		(*pts).push_back( std::make_pair(i, sqrt(radio*radio - ((i - x)*(i - x)) + y)));
	}
	for(double i = x - radio ; i < x + radio; i+= fact) {
        std::cout << init << "** " << -i << " " << - sqrt(radio*radio - ((i - x)*(i - x)) + y) << std::endl;
		(*pts).push_back(std::make_pair(-i, - sqrt(radio*radio - ((i - x)*(i - x)) + y)));
	}
}

main(){

    Gnuplot gp;

	std::cout << "Press Ctrl-C to quit (closing gnuplot window doesn't quit)." << std::endl;

	gp << "set yrange [-5:5]\n";
    gp << "set xrange [-5:5]\n";

	const int N = 1000;
    std::vector<std::pair<double, double> > pts;

	double theta = 0;
    int i = 0, max = 1;
	while(i < max) {

		//for(int i=0; i<N; i++) {
//			double alpha = (double(i)/N-0.5) * 10;
//			pts[i] = sin(alpha*8.0 + theta) * exp(-alpha*alpha/2.0);
//		}
        
        //for(int it = 0; it < N; it++)
        //    std::cout << it << " " << pts[it] << std::endl;

        planetGenerator(&pts, 1, 1, 2 );

        //for(int it = 0; it < pts.size(); it++)
        //    std::cout << it << " " << pts[it][0] << std::endl;
		gp << "set ytics 1 \n";
		gp << "set xtics 1 \n";
		gp << "set grid \n";
		gp << "plot '-' with points pointtype 5 \n";
		//gp << "plot '-' with lines \n";
		gp.send1d(pts);
		gp.flush();

		theta += 0.2;
		mysleep(100);
        i++;
	}
}